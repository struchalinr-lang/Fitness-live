# FitTrainer Live — Telegram Liquid Glass Edition (v2.0)

Рабочий инструмент персонального фитнес-тренера в дизайне **Telegram iOS / macOS Liquid Glass**.
