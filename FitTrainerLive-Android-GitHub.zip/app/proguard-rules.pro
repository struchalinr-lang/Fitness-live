-keepclassmembers class com.fittrainer.live.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
